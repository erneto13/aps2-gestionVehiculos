export interface User {
    iddriver: number;
    name: string;
    license_number: string;
    phone: string;
    email: string;
    address: string;
    user_id: number;
}