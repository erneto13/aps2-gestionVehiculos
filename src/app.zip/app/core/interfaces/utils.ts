export interface OverviewCard {
    value: number;
    label: string,
    icon: string
}