export interface Recovery {
    email: string,
}