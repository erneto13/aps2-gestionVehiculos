export interface Usuario {
    email: string,
    role: string,
}