import { Component } from '@angular/core';

@Component({
  selector: 'footer-landing',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
})
export class FooterLandingPage {

}
